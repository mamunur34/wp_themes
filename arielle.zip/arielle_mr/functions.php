<?php
/**
 * Arielle functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Arielle
 */

if ( ! function_exists( 'arielle_mr_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function arielle_mr_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Arielle, use a find and replace
		 * to change 'arielle_mr' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'arielle_mr', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(array('menu-1' => esc_html__( 'Primary', 'arielle_mr' )));
                register_nav_menus(array('overly_menu_1' => esc_html__( 'Overly_1', 'arielle_mr')));
                register_nav_menus(array('overly_menu_2' => esc_html__( 'Overly_2', 'arielle_mr')));
                register_nav_menus(array('overly_menu_3' => esc_html__( 'Overly_3', 'arielle_mr' )));
                register_nav_menus(array('footer_menu' => esc_html__( 'Footer Menu', 'arielle_mr' )));
 
 

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'arielle_mr_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'arielle_mr_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function arielle_mr_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'arielle_mr_content_width', 640 );
}
add_action( 'after_setup_theme', 'arielle_mr_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function arielle_mr_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'arielle_mr' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'arielle_mr' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 1', 'arielle_mr' ),
		'id'            => 'footer-widget-1',
		'description'   => esc_html__( 'Footer widget 1.', 'arielle_mr' ),
		'before_widget' => '<div id="%1$s" class="col-md-3 widget %2$s ">',
		'after_widget'  => '</div>',
		 'before_title'  => '<h2 class="widget-title">',
		 'after_title'   => '</h2>',
	) );
	 
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 2', 'arielle_mr' ),
		'id'            => 'footer-widget-2',
		'description'   => esc_html__( 'Footer widget 2.', 'arielle_mr' ),
		'before_widget' => '<div id="%1$s" class="col-md-3 widget %2$s ">',
		'after_widget'  => '</div>',
		 'before_title'  => '<h2 class="widget-title">',
		 'after_title'   => '</h2>',
	) );
	 
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 3', 'arielle_mr' ),
		'id'            => 'footer-widget-3',
		'description'   => esc_html__( 'Footer widget 3.', 'arielle_mr' ),
		'before_widget' => '<div id="%1$s" class="col-md-3 widget %2$s ">',
		'after_widget'  => '</div>',
		 'before_title'  => '<h2 class="widget-title">',
		 'after_title'   => '</h2>',
	) );
	 
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 4', 'arielle_mr' ),
		'id'            => 'footer-widget-4',
		'description'   => esc_html__( 'Footer widget 4.', 'arielle_mr' ),
		'before_widget' => '<div id="%1$s" class="col-md-3 widget %2$s ">',
		'after_widget'  => '</div>',
		 'before_title'  => '<h2 class="widget-title">',
		 'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'arielle_mr_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function arielle_mr_scripts() {
	wp_enqueue_style( 'arielle_mr-style', get_stylesheet_uri() );

	wp_enqueue_script( 'arielle_mr-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'arielle_mr-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'arielle_mr_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

require get_template_directory() . '/ReduxCore/framework.php';
require get_template_directory() . '/assets/redux_custom_config.php';

require get_template_directory() . '/assets/mr_cmb2.php';

function the_breadcrumb() {
		echo '<ul id="crumbs" class="list-inline breadcrumbs__nav mr_custom_ul">';
	if (!is_home()) {
		echo '<li class="list-inline-item"><a class="read__more" href="';
		echo get_option('home');
		echo '">';
		echo 'Home';
		echo "</a></li>";
		if (is_category() || is_single()) {
			echo '<li class="list-inline-item">';
			the_category(' </li><li class="list-inline-item"> ');
			if (is_single()) {
				echo '</li><li class="list-inline-item">';
				the_title();
				echo '</li>';
			}
		} elseif (is_page()) {
			echo '<li class="list-inline-item">';
			echo the_title();
			echo '</li>';
		}
	}
	elseif (is_tag()) {single_tag_title();}
	elseif (is_day()) {echo'<li class="list-inline-item">Archive for '; the_time('F jS, Y'); echo'</li>';}
	elseif (is_month()) {echo'<li class="list-inline-item">Archive for '; the_time('F, Y'); echo'</li>';}
	elseif (is_year()) {echo'<li class="list-inline-item">Archive for '; the_time('Y'); echo'</li>';}
	elseif (is_author()) {echo '<li class="list-inline-item">Author Archive'; echo'</li>';}
	elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo '<li class="list-inline-item">Blog Archives'; echo'</li>';}
	elseif (is_search()) {echo '<li class="list-inline-item">Search Results'; echo'</li>';}
	echo '</ul>';
}
 

