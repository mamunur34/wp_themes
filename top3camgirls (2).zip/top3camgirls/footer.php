		
</div><!-- mr_wrap -->
<?php wp_footer(); ?>
<script>
    
    document.getElementById('myframe').onscroll = function(){
	 	alert('scrolling page');
};
</script>
</body>
</html>
