<?php

    class Redux_Customizer_Control_checkbox extends Redux_Customizer_Control {
        public $type = "redux-checkbox";
    }
    class Redux_Customizer_Control_color_rgba extends Redux_Customizer_Control {
        public $type = "redux-color_rgba";
    }
    class Redux_Customizer_Control_color extends Redux_Customizer_Control {
        public $type = "redux-color";
    }
    //class Redux_Customizer_Control_raw extends Redux_Customizer_Control {
    //    public $type = "redux-raw";
    //}
    class Redux_Customizer_Control_media extends Redux_Customizer_Control {
        public $type = "redux-media";
    }
    class Redux_Customizer_Control_spinner extends Redux_Customizer_Control {
        public $type = "redux-spinner";
    }
    class Redux_Customizer_Control_palette extends Redux_Customizer_Control {
        public $type = "redux-palette";
    }
    class Redux_Customizer_Control_button_set extends Redux_Customizer_Control {
        public $type = "redux-button_set";
    }
    class Redux_Customizer_Control_image_select extends Redux_Customizer_Control {
        public $type = "redux-image_select";
    }
    class Redux_Customizer_Control_radio extends Redux_Customizer_Control {
        public $type = "redux-radio";
    }
    class Redux_Customizer_Control_select extends Redux_Customizer_Control {
        public $type = "redux-select";
    }
    class Redux_Customizer_Control_gallery extends Redux_Customizer_Control {
        public $type = "redux-gallery";
    }
    class Redux_Customizer_Control_slider extends Redux_Customizer_Control {
        public $type = "redux-slider";
    }
    class Redux_Customizer_Control_sortable extends Redux_Customizer_Control {
        public $type = "redux-sortable";
    }
    class Redux_Customizer_Control_switch extends Redux_Customizer_Control {
        public $type = "redux-switch";
    }
    class Redux_Customizer_Control_text extends Redux_Customizer_Control {
        public $type = "redux-text";
    }
    class Redux_Customizer_Control_textarea extends Redux_Customizer_Control {
        public $type = "redux-textarea";
    }