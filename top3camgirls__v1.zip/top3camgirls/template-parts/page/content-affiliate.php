<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$iframe_url = $banner_img_url =  $header_height = $header_text = $cta_link = 
$cta_link = $header_html = $radio_check = $bgcolor = $copy = $tracking_code = "";
 

//echo get_the_ID();
 //print_r(get_post_meta( get_the_ID()));
$iframe_url = get_post_meta( get_the_ID(), 'custom_iframe_url', true );
$banner_img_url = get_post_meta( get_the_ID(), 'custom_banner_img_url', true );
$header_height = get_post_meta( get_the_ID(), 'custom_header_height', true );
$header_text = get_post_meta( get_the_ID(), 'custom_header_text', true );
$cta_link = get_post_meta( get_the_ID(), 'custom_call_to_action_link', true );
$cta_btn_txt = get_post_meta( get_the_ID(), 'custom_call_to_action_button_text', true );
$header_html = get_post_meta( get_the_ID(), 'custom_header_html', true );
$radio_check = get_post_meta( get_the_ID(), 'custom_radio_inline_html_cta', true );
$bgcolor = get_post_meta( get_the_ID(), 'custom_header_bgcolor', true );
$copy = get_post_meta( get_the_ID(), 'custom_footer_copyright', true );
$tracking_code = get_post_meta( get_the_ID(), 'custom_footer_tracking_code', true );
$custom_header_h1_color = get_post_meta( get_the_ID(), 'custom_header_h1_color', true );
  $custom_footer_bgcolor = get_post_meta( get_the_ID(), 'custom_footer_bgcolor', true );
?>
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<section class="call-to-action">
    <div class="container">
        <?php if ($radio_check == 'cta' ):?> 
        <div class="row">
            
    	    <div class="col-md-8 col-sm-8   m-text-center">
                <a href="<?php echo $cta_link;?>" class="btn btn-lg btn-block btn-danger"><h1><?php echo $cta_btn_txt;?></h1></a>
            </div>
 
            
        </div>
        <?php endif;?>
        <?php if ($radio_check == 'html' ):?> 
            <?php echo $header_html;?>
        <?php endif;?>
    </div>
</section>
<?php 
    $mr_iframe_html='<iframe style="position:fixed; top:';
    $mr_iframe_html.= 0 + $header_height;
    $mr_iframe_html.='px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;" src="';
    $mr_iframe_html.=$iframe_url;
    $mr_iframe_html.='" ></iframe>';
    
    
       echo $mr_iframe_html;
?>
 <?php /* <iframe style="position:fixed; top:300px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;" src="<?php echo $iframe_url;?>" ></iframe>*/?>
 
 
<style>
    #mr_wrap{background:<?php echo $bgcolor;?>;}
    #content {padding: 0; margin: 0;}
section { }

h1{
    text-transform:uppercase; 
    color:<?php echo $custom_header_h1_color;?>; 
    font-family:Arial;
    font-size:40px;
    }

.btn {
    border-radius: 5px;
    margin: 21px 0 0 0;
    font-weight:700;
}



@media (max-width: 768px) {
    .m-text-center {text-align:center;}
    .call-to-action h1{font-size:20px;}
}
@media (max-width: 1024px) {
    .m-text-center {text-align:center;}
    .call-to-action h1{font-size:25px;}
}

    footer{
        display: block;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 99999999999999;
    height: 50px;
    width: 100%;
 
    }
    
</style>

<footer id="colophon" class="site-footer" role="contentinfo" style="background:<?php echo $custom_footer_bgcolor;?>">
        <div class="wrap">
            <p class="footer_text"> <?php echo $copy; ?>  </p>
            <?php echo $tracking_code; ?>
        </div><!-- .wrap -->
</footer><!-- #colophon -->