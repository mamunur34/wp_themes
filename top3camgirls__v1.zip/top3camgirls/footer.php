<?php
/**
 * Customized footer
 */

?>

		
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>
